from django.apps import AppConfig


class MpesaappConfig(AppConfig):
    name = 'mpesaApp'
    verbose_name = "mpesaApp"
