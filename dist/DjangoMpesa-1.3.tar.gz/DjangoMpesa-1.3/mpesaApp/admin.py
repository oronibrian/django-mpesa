from django.contrib import admin
from mpesaApp.models import mpesaDetail,payment
# Register your models here.
admin.site.register(mpesaDetail)
admin.site.register(payment)